export interface CustomerAuthContext {
  userId: number;
  email: string;
}
