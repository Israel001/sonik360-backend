import { Controller, Get, Param, ParseIntPipe, Query } from '@nestjs/common';
import { ProductsService } from './products.service';

@Controller('products')
export class ProductsController {
  constructor(private readonly productService: ProductsService) {}

  @Get('/search/:query')
  search(@Param('query') query: string) {
    return this.productService.search(query);
  }

  @Get()
  fetch(
    @Query('filter') filter: string,
    @Query('minPrice', ParseIntPipe) minPrice: number,
    @Query('maxPrice', ParseIntPipe) maxPrice: number,
  ) {
    return this.productService.fetch({ filter, minPrice, maxPrice });
  }

  @Get('/brands')
  fetchBrands() {
    return this.productService.fetchBrands();
  }

  @Get('/:name')
  getByName(@Param('name') name: string) {
    return this.productService.getByName(name);
  }
}
