import { bootstrap } from "./main";

bootstrap();